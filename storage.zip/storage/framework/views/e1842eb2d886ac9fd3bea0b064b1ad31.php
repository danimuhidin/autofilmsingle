<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', $bio->title); ?></title>
    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">
    <link rel="stylesheet"
        href="<?php echo e(asset('vendor/plugins/fontawesome-free/css/all.min.css')); ?>?v=<?php echo e(env('ASSET_VERSION')); ?>">
    <link rel="stylesheet"
        href="<?php echo e(asset('vendor/plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css')); ?>?v=<?php echo e(env('ASSET_VERSION')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendor/dist/css/adminlte.min.css')); ?>?v=<?php echo e(env('ASSET_VERSION')); ?>">
    <link rel="stylesheet"
        href="<?php echo e(asset('vendor/plugins/OwlCarousel2/owl.carousel.min.css')); ?>?v=<?php echo e(env('ASSET_VERSION')); ?>">
    <link rel="stylesheet"
        href="<?php echo e(asset('vendor/plugins/OwlCarousel2/owl.theme.default.min.css')); ?>?v=<?php echo e(env('ASSET_VERSION')); ?>">
    <link rel="stylesheet"
        href="<?php echo e(asset('vendor/plugins/lightbox2/lightbox.min.css')); ?>?v=<?php echo e(env('ASSET_VERSION')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>?v=<?php echo e(env('ASSET_VERSION')); ?>">
    <script src="<?php echo e(asset('vendor/plugins/jquery/jquery.min.js')); ?>?v=<?php echo e(env('ASSET_VERSION')); ?>"></script>
    <?php echo $__env->yieldContent('styles'); ?>
</head>

<body class="hold-transition sidebar-mini" data-spy="scroll" data-target="#mainNavbar" data-offset="80">
    <div class="wrapper">
        <header>
            <nav class="navbar navbar-expand-lg navbar-dark fixed-top" id="mainNavbar">
                <div class="container">
                    <a class="navbar-brand" href="<?php echo e(URL::to('/')); ?>">
                        <img src="<?php echo e(asset('storage/' . $bio->brand_img)); ?>" alt="<?php echo e($bio->brand_name); ?>"
                            height="40">
                    </a>

                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
                        aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                    </button>
                    <div class="collapse navbar-collapse" id="navbarNav">
                        <ul class="navbar-nav ml-auto">
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(URL::to('/')); ?>">Home</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(URL::to('produk')); ?>">Produk</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(URL::to('galeri')); ?>">Galeri</a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(URL::to('about')); ?>">Tentang Kami</a>
                            </li>
                            <li class="nav-item dropdown">
                                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdownKontak"
                                    role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    Kontak & Outlet
                                </a>
                                <div class="dropdown-menu" aria-labelledby="navbarDropdownKontak">
                                    <a class="dropdown-item" href="<?php echo e(URL::to('contact')); ?>">Hubungi Kami (HQ)</a>
                                    <a class="dropdown-item" href="<?php echo e(URL::to('outlet')); ?>">Daftar Outlet</a>
                                </div>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="<?php echo e(URL::to('partner')); ?>">Partner</a>
                            </li>
                        </ul>
                    </div>
                </div>
            </nav>
        </header>

        <?php echo $__env->yieldContent('content'); ?>

        <footer>
            <div class="container">
                <div class="row">
                    <div class="col-lg-4 col-md-6 mb-4">
                        <img class="mb-2" src="<?php echo e(asset('storage/' . $bio->brand_img)); ?>"
                            alt="<?php echo e($bio->brand_name); ?>" height="50">
                        <p><?php echo $bio->greeting_about; ?></p>
                    </div>
                    <div class="col-lg-2 col-md-6 mb-4">
                        <h5>Quick Links</h5>
                        <ul>
                            <li><a href="<?php echo e(URL::to('/')); ?>">Home</a></li>
                            <li><a href="<?php echo e(URL::to('galeri')); ?>">Galeri</a></li>
                            <li><a href="<?php echo e(URL::to('about')); ?>">Tentang Kami</a></li>
                            <li><a href="<?php echo e(URL::to('contact')); ?>">Kontak</a></li>
                            <li><a href="<?php echo e(URL::to('outlet')); ?>">Outlet</a></li>
                            <li><a href="<?php echo e(URL::to('partner')); ?>">Partner</a></li>
                            <li><a href="<?php echo e(URL::to('admin/dashboard')); ?>">Administrator</a></li>
                        </ul>
                    </div>
                    <div class="col-lg-3 col-md-6 mb-4">
                        <h5>Kontak</h5>
                        <p>
                            <i class="fas fa-map-marker-alt"></i> <?php echo e($bio->address); ?>

                        </p>
                        <p>
                            <i class="fas fa-phone-alt"></i>
                            <a class="text-white-50" href="https://wa.me/<?php echo e(format_whatsapp($bio->whatsapp)); ?>"
                                target="_blank"><?php echo e($bio->whatsapp); ?></a>
                        </p>
                        <p>
                            <i class="fas fa-envelope"></i>
                            <a class="text-white-50" href="mailto:<?php echo e($bio->email); ?>"><?php echo e($bio->email); ?></a>
                        </p>
                    </div>
                    <div class="col-lg-3 col-md-6 mb-4">
                        <h5>Ikuti Kami</h5>
                        <p>Dapatkan info terbaru dan promo menarik.</p>
                        <div class="social-icons">
                            <a target="_blank" href="<?php echo e($bio->fb_link); ?>"><i class="fab fa-facebook-f"></i></a>
                            <a target="_blank" href="<?php echo e($bio->ig_link); ?>"><i class="fab fa-instagram"></i></a>
                            <a target="_blank" href="<?php echo e($bio->youtube_link); ?>"><i class="fab fa-youtube"></i></a>
                        </div>
                    </div>
                </div>
                <div class="footer-bottom">
                    <p>&copy; 2025 <?php echo e($bio->brand_name); ?>. All Rights Reserved.</p>
                </div>
            </div>
        </footer>

        <div class="wa-bubble-wrapper">
            <div id="wa-menu">
                <?php $__currentLoopData = $waBubble; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $contact): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a href="https://wa.me/<?php echo e(format_whatsapp($contact->telp)); ?>" target="_blank">
                        <i class="fas fa-map-pin"></i> <?php echo e($contact->name); ?>

                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div id="wa-toggle">
                <i class="fab fa-whatsapp"></i>
            </div>
        </div>
    </div>

    <script src="<?php echo e(asset('vendor/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>?v=<?php echo e(env('ASSET_VERSION')); ?>">
    </script>
    <script src="<?php echo e(asset('vendor/plugins/sweetalert2/sweetalert2.min.js')); ?>?v=<?php echo e(env('ASSET_VERSION')); ?>"></script>
    <script src="<?php echo e(asset('vendor/plugins/chart.js/Chart.min.js')); ?>?v=<?php echo e(env('ASSET_VERSION')); ?>"></script>
    <script src="<?php echo e(asset('vendor/plugins/OwlCarousel2/owl.carousel.min.js')); ?>?v=<?php echo e(env('ASSET_VERSION')); ?>"></script>
    <script src="<?php echo e(asset('vendor/plugins/lightbox2/lightbox.min.js')); ?>?v=<?php echo e(env('ASSET_VERSION')); ?>"></script>
    <script src="<?php echo e(asset('vendor/dist/js/adminlte.min.js')); ?>?v=<?php echo e(env('ASSET_VERSION')); ?>"></script>
    <script>
        $(window).scroll(function() {
            if ($(this).scrollTop() > 50) {
                $('.navbar').addClass('scrolled');
            } else {
                $('.navbar').removeClass('scrolled');
            }
        });

        $('a.nav-link[href^="#"]').on('click', function(event) {
            var target = $(this.getAttribute('href'));
            if (target.length) {
                event.preventDefault();
                $('html, body').stop().animate({
                    scrollTop: target.offset().top - 70
                }, 800);
            }

            if ($('.navbar-toggler').is(':visible')) {
                $('.navbar-collapse').collapse('hide');
            }
        });

        $('#wa-toggle').on('click', function() {
            $('#wa-menu').slideToggle(300);
        });
        $(document).on('click', function(event) {
            if (!$(event.target).closest('.wa-bubble-wrapper').length) {
                if ($('#wa-menu').is(':visible')) {
                    $('#wa-menu').slideUp(300);
                }
            }
        });
    </script>
    <?php echo $__env->yieldPushContent('scripts'); ?>

</body>

</html>
<?php /**PATH D:\Coding\portofolio\kacafilm\resources\views/layouts/app.blade.php ENDPATH**/ ?>