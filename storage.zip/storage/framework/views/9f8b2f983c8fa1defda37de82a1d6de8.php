

<?php $__env->startSection('title', 'Mantra Sakti Autofilm - Spesialis Kaca Film Mobil & Gedung'); ?>
<?php $__env->startSection('page-title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>

    <section class="page-hero container-fluid" style="background-image: url(<?php echo e(asset('storage/' . $hero->image)); ?>);">
        <div class="hero-overlay"></div>
        <div class="hero-content">
            <h1 class="display-4 font-weight-bold"><?php echo e($hero->title); ?></h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(URL::to('/')); ?>">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Daftar Outlet</li>
                </ol>
            </nav>
        </div>
    </section>

    <section class="pb-5">
        <div class="container">
            <div class="section-title mt-5">
                <h2>Hubungi Kami & Temukan Outlet</h2>
                <p>Siap membantu kebutuhan Anda di Kantor Pusat atau cabang terdekat.</p>
            </div>

            <?php $__currentLoopData = $outlets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $outlet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php if($key != 0): ?> 
                <hr class="custom-hr">
                <?php endif; ?>

                <div class="row my-5 align-items-center">
                    <div class="col-md-6 mb-4 mb-md-0">
                        <div class="embed-responsive embed-responsive-16by9">
                            <iframe
                                src="<?php echo e($outlet->link1); ?>"
                                class="embed-responsive-item map-embed" allowfullscreen="" loading="lazy"
                                referrerpolicy="no-referrer-when-downgrade"></iframe>
                        </div>
                    </div>
                    <div class="col-md-6 outlet-info">
                        <h3><?php echo e($outlet->name); ?></h3>
                        <ul class="mt-4">
                            <li>
                                <i class="fas fa-map-marker-alt"></i>
                                <div>
                                    <strong>Alamat:</strong><br>
                                    <?php echo e($outlet->address); ?>

                                </div>
                            </li>
                            <li>
                                <i class="fab fa-whatsapp"></i>
                                <div><strong>WhatsApp:</strong> <?php echo e($outlet->telp); ?></div>
                            </li>
                            <li>
                                <i class="fas fa-clock"></i>
                                <div><strong>Jam Operasional:</strong> <?php echo e($outlet->operation_hours); ?></div>
                            </li>
                        </ul>
                        <a href="https://wa.me/<?php echo e(format_whatsapp($outlet->telp)); ?>" target="_blank" class="btn btn-merah mr-2 mt-3">
                            <i class="fab fa-whatsapp"></i>
                            Hubungi via WhatsApp
                        </a>
                        <a href="<?php echo e($outlet->link2); ?>" target="_blank"
                            class="btn btn-outline-light mt-3">
                            <i class="fas fa-map-marked-alt"></i>
                            Buka di Google Maps
                        </a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/mant3325/public_html/dev.mantrasaktiautofilm.com/resources/views/outlet.blade.php ENDPATH**/ ?>