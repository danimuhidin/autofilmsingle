

<?php $__env->startSection('title', 'Mantra Sakti Autofilm - Spesialis Kaca Film Mobil & Gedung'); ?>
<?php $__env->startSection('page-title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>

    <section class="page-hero container-fluid" style="background-image: url(<?php echo e(asset('storage/' . $hero->image)); ?>);">
        <div class="hero-overlay"></div>
        <div class="hero-content">
            <h1 class="display-4 font-weight-bold"><?php echo e($hero->title); ?></h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(URL::to('/')); ?>">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Tentang Kami</li>
                </ol>
            </nav>
        </div>
    </section>

    <section class="section-padding">
        <div class="container">
            <div class="row align-items-center">

                <div class="col-lg-6">
                    <h4 class="mb-3" style="color: var(--warna-kuning-aksen);">
                        <?php echo e($bio->tagline); ?>

                    </h4>
                    <p>
                        <?php echo $bio->greeting_about; ?>

                    </p>
                </div>
                <div class="col-lg-6 mb-4 mb-lg-0 pl-lg-4">
                    <img src="<?php echo e(asset('storage/' . $bio->img_about)); ?>" alt="Workshop Mantra Sakti Autofilm"
                        class="img-fluid rounded shadow-lg">
                </div>
            </div>
        </div>
    </section>

    <section class="section-padding" style="background-color: var(--warna-latar-sekunder);">
        <div class="container">
            <div class="row">
                <!-- Kolom Kiri: Visi -->
                <div class="col-md-6 text-center text-md-left mb-5 mb-md-0">
                    <i class="fas fa-eye vision-mission-icon"></i>
                    <h3 class="font-weight-bold mb-3">Visi Kami</h3>
                    <p>
                        <?php echo e($vision->desc); ?>

                    </p>
                </div>
                <!-- Kolom Kanan: Misi -->
                <div class="col-md-6 text-center text-md-left">
                    <i class="fas fa-bullseye vision-mission-icon"></i>
                    <h3 class="font-weight-bold mb-3">Misi Kami</h3>
                    <ul class="mission-list">
                        <?php $__currentLoopData = $mission; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($item->desc); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        </div>
    </section>

    <section class="section-padding">
        <div class="container">
            <div class="section-title">
                <h2>Nilai-Nilai Inti Kami</h2>
                <p>
                    Pilar yang menjadi fondasi kepercayaan pelanggan kami.
                </p>
            </div>
            <div class="row justify-content-center">
                <?php $__currentLoopData = $keunggulans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keunggulan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-6 col-lg-4 mb-4">
                        <div class="feature-box">
                            <div class="icon mb-3">
                                <img src="<?php echo e(asset('storage/' . $keunggulan->image)); ?>" alt="<?php echo e($keunggulan->title); ?>"
                                    style="width: 60px; height: 60px;">
                            </div>
                            <h5><?php echo e($keunggulan->title); ?></h5>
                            <p>
                                <?php echo e($keunggulan->desc); ?>

                            </p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/mant3325/public_html/dev.mantrasaktiautofilm.com/resources/views/about.blade.php ENDPATH**/ ?>