

<?php $__env->startSection('title', 'Admin Dashboard'); ?>
<?php $__env->startSection('page-title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Selamat Datang, Admin!</h3>
                </div>
                <div class="card-body">
                    Ini adalah halaman dashboard Anda. Anda bisa mulai menambahkan konten di sini.
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/mant3325/public_html/dev.mantrasaktiautofilm.com/resources/views/admin/dashboard.blade.php ENDPATH**/ ?>