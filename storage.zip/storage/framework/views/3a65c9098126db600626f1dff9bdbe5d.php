<?php $__env->startSection('title', 'Mantra Sakti Autofilm - Spesialis Kaca Film Mobil & Gedung'); ?>
<?php $__env->startSection('page-title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>

    <section class="hero-carousel p-0" id="home">
        <div class="owl-carousel owl-theme" id="hero-slider">
            <?php $__currentLoopData = $jumbotrons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jumbotron): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="item" style="background-image: url('<?php echo e(asset('storage/' . $jumbotron->image)); ?>');">
                    <div class="hero-overlay">
                        <div class="container hero-content">
                            <h1><?php echo e($jumbotron->title); ?></h1>
                            <p><?php echo e($jumbotron->desc); ?></p>
                            <a href="<?php echo e($jumbotron->link); ?>" class="btn btn-merah">
                                Explore Now
                            </a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </section>

    <section id="tentang-kami" class="section-padding bg-dark">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6 mb-4 mb-lg-0 pr-lg-4">
                    <img src="<?php echo e(asset('storage/' . $bio->img_home)); ?>" class="img-fluid rounded"
                        alt="<?php echo e($bio->brand_name); ?>">
                </div>
                <div class="col-lg-6">
                    <h3 class="mb-3" style="color: var(--warna-kuning-aksen);">Selamat Datang di <?php echo e($bio->brand_name); ?>

                    </h3>
                    <h4 class="mb-4"><?php echo e($bio->tagline); ?></h4>
                    <p class="text-white-50">
                        <?php echo $bio->greeting_home; ?>

                    </p>
                </div>
            </div>
        </div>
    </section>

    <section id="outlet-kami" class="section-padding bg-light">
        <div class="container">
            <div class="section-title">
                <h2>
                    Outlet Tersedia di Berbagai Kota
                </h2>
                <p>
                    Temukan lokasi outlet resmi Mantra Sakti terdekat di kota Anda.
                </p>
            </div>
            <div class="row">
                <?php $__currentLoopData = $outlets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $outlet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-3">
                        <div class="card">
                            <img src="<?php echo e(asset('storage/' . $outlet->image)); ?>" alt="<?php echo e($outlet->name); ?>"/>
                            <div class="card-body">
                                <h3 class="title"><?php echo e($outlet->name); ?></h3>
                                <p class="desc"> <?php echo e($outlet->address); ?></p>
                                <div class="meta">
                                    <a href="https://wa.me/<?php echo e(format_whatsapp($outlet->telp)); ?>" target="_blank"
                                        class="me-2">
                                        <span>📞 <?php echo e($outlet->telp); ?></span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

    <section id="produk-kami" class="section-padding bg-dark">
        <div class="container">
            <div class="section-title">
                <h2>Pilihan Produk Kaca Film</h2>
                <p>
                    Berikut adalah beberapa produk kaca film unggulan yang kami tawarkan. Setiap produk dirancang
                    untuk memberikan performa terbaik dalam menolak panas, melindungi dari sinar UV, dan meningkatkan
                    kenyamanan.
                </p>
            </div>
            <div class="row d-flex justify-content-center">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-3 col-md-6 mb-4">
                        <div class="card product-card h-100">
                            <img src="<?php echo e(asset('storage/' . $product->icon)); ?>" class="card-img-top"
                                alt="Logo <?php echo e($product->name); ?>">
                            <div class="card-body d-flex flex-column">
                                <h5 class="card-title"><?php echo e($product->name); ?></h5>
                                <p class="card-text text-muted-light small">
                                    <?php echo e($product->short_desc); ?>

                                </p>
                                <ul class="list-unstyled small my-2">
                                    <li><i class="fas fa-sun fa-fw"></i> <strong>VLT :</strong> <?php echo e($product->vlt); ?></li>
                                    <li><i class="fas fa-shield-alt fa-fw"></i> <strong>UVR :</strong> <?php echo e($product->uvr); ?>

                                    </li>
                                    <li><i class="fas fa-thermometer-half fa-fw"></i> <strong>IRR :</strong>
                                        <?php echo e($product->irr); ?></li>
                                    <li><i class="fas fa-star fa-fw"></i> <strong>TSER :</strong> <?php echo e($product->tser); ?></li>
                                </ul>
                                <a href="<?php echo e(URL::to('detail-produk/' . $product->id)); ?>"
                                    class="btn btn-merah mt-auto">Lihat
                                    Detail</a>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

    <section id="keunggulan" class="section-padding bg-light">
        <div class="container">
            <div class="section-title">
                <h2>Mengapa Memilih Mantra Sakti?</h2>
                <p>Komitmen kami adalah kepuasan dan jaminan kualitas.</p>
            </div>
            <div class="row justify-content-center">
                <?php $__currentLoopData = $keunggulans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $keunggulan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-6 mb-4">
                        <div class="keunggulan-item">
                            <div class="icon">
                                <img src="<?php echo e(asset('storage/' . $keunggulan->image)); ?>" alt="<?php echo e($keunggulan->title); ?>"
                                    style="width: 60px; height: 60px;">
                            </div>
                            <h4><?php echo e($keunggulan->title); ?></h4>
                            <p class="text-white-50">
                                <?php echo e($keunggulan->desc); ?>

                            </p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

    <section id="galeri" class="section-padding bg-dark">
        <div class="container">
            <div class="section-title">
                <h2>Portofolio Pemasangan Kami</h2>
                <p>Lihat hasil kerja presisi dari tim profesional kami.</p>
            </div>

            <div class="row gallery-container mb-3 d-flex justify-content-center">
                <?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $gallery): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-4 col-md-6 mb-4 gallery-item-wrapper">
                        <div class="gallery-item">
                            <a href="<?php echo e(asset('storage/' . $gallery->image)); ?>" data-lightbox="galeri-portofolio"
                                data-title="<?php echo e($gallery->title); ?>">
                                <img src="<?php echo e(asset('storage/' . $gallery->image)); ?>" class="img-fluid"
                                    alt="<?php echo e($gallery->title); ?>">
                                <div class="overlay-icon"><i class="fas fa-search-plus"></i></div>
                            </a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>

            <div class="row">
                <?php $__currentLoopData = $youtubes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $youtube): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-6 mb-4 mb-lg-0 video-wrapper">
                        <div class="embed-responsive embed-responsive-16by9">
                            <iframe title="YouTube video player" class="embed-responsive-item" src="<?php echo e($youtube->link); ?>" allowfullscreen></iframe>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

    <section id="testimoni" class="section-padding bg-light">
        <div class="container">
            <div class="section-title">
                <h2>Apa Kata Pelanggan Kami</h2>
                <p>Kepuasan mereka adalah prioritas utama kami.</p>
            </div>
            <div class="owl-carousel owl-theme" id="testimoni-slider">
                <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="item">
                        <div class="testimoni-item">
                            <div class="stars">
                                <i class="fas fa-star"></i><i class="fas fa-star"></i><i class="fas fa-star"></i><i
                                    class="fas fa-star"></i><i class="fas fa-star"></i>
                            </div>
                            <p class="quote">"<?php echo e($testimonial->desc); ?>"</p>
                            <h5 class="author"><?php echo e($testimonial->name); ?></h5>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </section>

    <section id="partner" class="section-padding bg-dark">
        <div class="container">
            <div class="section-title">
                <h2>Brand Partner Resmi Kami</h2>
                <p>Kami hanya bekerja dengan brand terbaik dan terpercaya.</p>
            </div>
            <div class="row align-items-center justify-content-center">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-2 col-md-4 col-6 partner-logo">
                        <img src="<?php echo e(asset('storage/' . $product->icon)); ?>" alt="<?php echo e($product->name); ?>"
                            class="img-fluid">
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

    <section id="kontak-outlet" class="section-padding bg-light">
        <div class="container">
            <div class="section-title">
                <h2>Hubungi Kami</h2>
                <p>Siap membantu kebutuhan Anda di Kantor Pusat atau cabang terdekat.</p>
            </div>

            <div class="row mb-5">
                <div class="col-lg-7 mb-4 mb-lg-0 contact-form">
                    <h4>Kirim Pertanyaan (Kantor Pusat)</h4>
                    <form action="#" method="POST">
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="inputNama">Nama Lengkap</label>
                                <input type="text" class="form-control" id="inputNama" placeholder="Nama Anda"
                                    required>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="inputEmail">Email</label>
                                <input type="email" class="form-control" id="inputEmail" placeholder="Email Anda"
                                    required>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="inputTelepon">Nomor Telepon</label>
                            <input type="tel" class="form-control" id="inputTelepon" placeholder="cth: 08123456789">
                        </div>
                        <div class="form-group">
                            <label for="inputPesan">Pesan Anda</label>
                            <textarea class="form-control" id="inputPesan" rows="5"
                                placeholder="Tuliskan kebutuhan atau pertanyaan Anda..." required></textarea>
                        </div>
                        <button type="submit" class="btn btn-merah">Kirim Pesan</button>
                    </form>
                </div>

                <div class="col-lg-5">
                    <h4>Informasi Kantor Pusat (HQ)</h4>
                    <p class="text-white-50">
                        Hubungi kami langsung di kantor pusat untuk layanan korporat, kemitraan, atau
                        konsultasi proyek skala besar.
                    </p>
                    <div class="contact-info">
                        <p>
                            <i class="fas fa-map-marker-alt"></i>
                            <?php echo e($bio->address); ?>

                        </p>
                        <p>
                            <i class="fas fa-phone-alt"></i>
                            <a class="text-white-50" href="https://wa.me/<?php echo e(format_whatsapp($bio->whatsapp)); ?>" target="_blank">
                                0812-4400-0805
                            </a>
                        </p>
                        <p>
                            <i class="fab fa-instagram"></i>
                            <a class="text-white-50"
                                href="<?php echo e($bio->ig_link); ?>"
                                target="_blank">
                                <?php echo e($bio->ig_name); ?>

                            </a>
                        </p>
                        <p><i class="fas fa-clock"></i> <strong>Jam Operasional</strong><br>
                            <?php echo e($bio->operation_time); ?>

                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('#hero-slider').owlCarousel({
                items: 1,
                loop: true,
                margin: 0,
                nav: false,
                dots: false,
                autoplay: true,
                autoplayTimeout: 7000,
                autoplayHoverPause: true,
                animateOut: 'fadeOut',
                navText: ['<i class="fas fa-chevron-left"></i>', '<i class="fas fa-chevron-right"></i>']
            });

            $('#testimoni-slider').owlCarousel({
                loop: true,
                margin: 30,
                nav: false,
                dots: true,
                autoplay: true,
                autoplayTimeout: 5000,
                autoplayHoverPause: true,
                responsive: {
                    0: {
                        items: 1
                    },
                    768: {
                        items: 2
                    },
                    992: {
                        items: 3
                    }
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Coding\portofolio\kacafilm\resources\views\home.blade.php ENDPATH**/ ?>