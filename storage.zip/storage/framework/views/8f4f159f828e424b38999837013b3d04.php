<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo $__env->yieldContent('title', 'Admin Panel'); ?></title>

    <link rel="stylesheet"
        href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700&display=fallback">

    <link rel="stylesheet"
        href="<?php echo e(asset('vendor/plugins/fontawesome-free/css/all.min.css')); ?>?v=<?php echo e(env('ASSET_VERSION')); ?>">
    <link rel="stylesheet"
        href="<?php echo e(asset('vendor/plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css')); ?>?v=<?php echo e(env('ASSET_VERSION')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('vendor/dist/css/adminlte.min.css')); ?>?v=<?php echo e(env('ASSET_VERSION')); ?>">
    <link rel="stylesheet"
        href="<?php echo e(asset('vendor/plugins/summernote/summernote-bs4.css')); ?>?v=<?php echo e(env('ASSET_VERSION')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/admin.css')); ?>?v=<?php echo e(env('ASSET_VERSION')); ?>">

    <?php echo $__env->yieldContent('styles'); ?>
</head>

<body class="hold-transition sidebar-mini">
    <div class="wrapper">

        <?php if(Auth::check()): ?>
            <nav class="main-header navbar navbar-expand navbar-white navbar-light">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i
                                class="fas fa-bars"></i></a>
                    </li>
                </ul>

                <ul class="navbar-nav ml-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(route('logout')); ?>"
                            onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                            <i class="fas fa-sign-out-alt"></i> Logout
                        </a>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                            <?php echo csrf_field(); ?>
                        </form>
                    </li>
                </ul>
            </nav>
            <aside class="main-sidebar sidebar-dark-primary elevation-4">
                <a href="<?php echo e(route('admin.dashboard')); ?>" class="brand-link">
                    <img src="<?php echo e(asset('storage/' . $bio->brand_img)); ?>" alt="<?php echo e($bio->brand_name); ?>"
                        class="img-fluid">
                </a>

                <div class="sidebar">

                    <nav class="mt-2">
                        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu"
                            data-accordion="false">
                            <li class="nav-item">
                                <a href="<?php echo e(route('admin.dashboard')); ?>"
                                    class="nav-link <?php echo e(request()->is('admin/dashboard*') ? 'active' : ''); ?>">
                                    <i class="nav-icon fas fa-tachometer-alt"></i>
                                    <p>
                                        Dashboard
                                    </p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('bios.index')); ?>"
                                    class="nav-link <?php echo e(request()->is('admin/bios*') ? 'active' : ''); ?>">
                                    <i class="nav-icon fas fa-info-circle"></i>
                                    <p>
                                        General
                                    </p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('users.index')); ?>"
                                    class="nav-link <?php echo e(request()->is('admin/users*') ? 'active' : ''); ?>">
                                    <i class="nav-icon fas fa-users"></i>
                                    <p>
                                        Kelola User
                                    </p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('contacts.index')); ?>"
                                    class="nav-link <?php echo e(request()->is('admin/contacts*') ? 'active' : ''); ?>">
                                    <i class="nav-icon fab fa-whatsapp"></i>
                                    <p>
                                        WhatsApp Bubble
                                    </p>
                                </a>
                            </li>
                            <li
                                class="nav-item <?php echo e(request()->is('admin/galleries*') || request()->is('admin/jumbotrons*') || request()->is('admin/heroes*') || request()->is('admin/youtubes*') ? 'menu-open' : ''); ?>">
                                <a href="#" class="nav-link">
                                    <i class="nav-icon far fa-image"></i>
                                    <p>
                                        Media
                                        <i class="fas fa-angle-left right"></i>
                                    </p>
                                </a>
                                <ul class="nav nav-treeview">
                                    <li class="nav-item">
                                        <a href="<?php echo e(route('galleries.index')); ?>"
                                            class="nav-link <?php echo e(request()->is('admin/galleries*') ? 'active' : ''); ?>">
                                            <i class="far fa-circle nav-icon"></i>
                                            <p>Gallery</p>
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="<?php echo e(route('jumbotrons.index')); ?>"
                                            class="nav-link <?php echo e(request()->is('admin/jumbotrons*') ? 'active' : ''); ?>">
                                            <i class="far fa-circle nav-icon"></i>
                                            <p>Jumbotron</p>
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="<?php echo e(route('heroes.index')); ?>"
                                            class="nav-link <?php echo e(request()->is('admin/heroes*') ? 'active' : ''); ?>">
                                            <i class="far fa-circle nav-icon"></i>
                                            <p>Hero</p>
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="<?php echo e(route('youtubes.index')); ?>"
                                            class="nav-link <?php echo e(request()->is('admin/youtubes*') ? 'active' : ''); ?>">
                                            <i class="far fa-circle nav-icon"></i>
                                            <p>Youtube</p>
                                        </a>
                                    </li>
                                </ul>
                            </li>

                            <li class="nav-item">
                                <a href="<?php echo e(route('outlets.index')); ?>"
                                    class="nav-link <?php echo e(request()->is('admin/outlets*') ? 'active' : ''); ?>">
                                    <i class="nav-icon fas fa-store"></i>
                                    <p>
                                        Kelola Outlet
                                    </p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('products.index')); ?>"
                                    class="nav-link <?php echo e(request()->is('admin/products*') ? 'active' : ''); ?>">
                                    <i class="nav-icon fas fa-box"></i>
                                    <p>
                                        Produk
                                    </p>
                                </a>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('partners.index')); ?>"
                                    class="nav-link <?php echo e(request()->is('admin/partners*') ? 'active' : ''); ?>">
                                    <i class="nav-icon fas fa-handshake"></i>
                                    <p>
                                        Kelola Partner
                                    </p>
                                </a>
                            </li>
                            <li
                                class="nav-item <?php echo e(request()->is('admin/visions*') || request()->is('admin/missions*') || request()->is('admin/posts*') ? 'menu-open' : ''); ?> ">
                                <a href="#" class="nav-link">
                                    <i class="nav-icon far fas fa-eye"></i>
                                    <p>
                                        Visi Misi & Keunggulan
                                        <i class="fas fa-angle-left right"></i>
                                    </p>
                                </a>
                                <ul class="nav nav-treeview">
                                    <li class="nav-item">
                                        <a href="<?php echo e(route('visions.index')); ?>"
                                            class="nav-link <?php echo e(request()->is('admin/visions*') ? 'active' : ''); ?>">
                                            <i class="far fa-circle nav-icon"></i>
                                            <p>Visi</p>
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="<?php echo e(route('missions.index')); ?>"
                                            class="nav-link <?php echo e(request()->is('admin/missions*') ? 'active' : ''); ?>">
                                            <i class="far fa-circle nav-icon"></i>
                                            <p>Misi</p>
                                        </a>
                                    </li>
                                    <li class="nav-item">
                                        <a href="<?php echo e(route('posts.index')); ?>"
                                            class="nav-link <?php echo e(request()->is('admin/posts*') ? 'active' : ''); ?>">
                                            <i class="far fa-circle nav-icon"></i>
                                            <p>Keunggulan</p>
                                        </a>
                                    </li>
                                </ul>
                            </li>
                            <li class="nav-item">
                                <a href="<?php echo e(route('testimonials.index')); ?>"
                                    class="nav-link <?php echo e(request()->is('admin/testimonials*') ? 'active' : ''); ?>">
                                    <i class="nav-icon fas fa-comment-dots"></i>
                                    <p>
                                        Testimoni
                                    </p>
                                </a>
                            </li>
                        </ul>
                    </nav>
                </div>
            </aside>
        <?php endif; ?>

        <div class="content-wrapper">
            <div class="content-header">
                <div class="container-fluid">
                    <div class="row mb-2">
                        <div class="col-sm-6">
                            <h1 class="m-0"><?php echo $__env->yieldContent('page-title'); ?></h1>
                        </div>
                    </div>
                </div>
            </div>
            <section class="content">
                <div class="container-fluid">

                    <?php echo $__env->yieldContent('content'); ?>

                </div>
            </section>
        </div>
        <footer class="main-footer">
            <strong>Copyright &copy; 2025 <a href="<?php echo e(URL::to('/')); ?>"><?php echo e($bio->brand_name); ?></a>.</strong>
            All rights reserved.
            <div class="float-right d-none d-sm-inline-block">
                <b>Version</b> 1.0.0
            </div>
        </footer>

    </div>
    <script src="<?php echo e(asset('vendor/plugins/jquery/jquery.min.js')); ?>?v=<?php echo e(env('ASSET_VERSION')); ?>"></script>

    <script src="<?php echo e(asset('vendor/plugins/bootstrap/js/bootstrap.bundle.min.js')); ?>?v=<?php echo e(env('ASSET_VERSION')); ?>">
    </script>
    <script src="<?php echo e(asset('vendor/plugins/sweetalert2/sweetalert2.min.js')); ?>?v=<?php echo e(env('ASSET_VERSION')); ?>"></script>
    <script src="<?php echo e(asset('vendor/plugins/chart.js/Chart.min.js')); ?>?v=<?php echo e(env('ASSET_VERSION')); ?>"></script>
    <script src="<?php echo e(asset('vendor/plugins/summernote/summernote-bs4.min.js')); ?>?v=<?php echo e(env('ASSET_VERSION')); ?>"></script>
    <script src="<?php echo e(asset('vendor/dist/js/adminlte.min.js')); ?>?v=<?php echo e(env('ASSET_VERSION')); ?>"></script>
    <script>
        $(document).ready(function() {
            $('.summernote').summernote({
                toolbar: [
                    ['style', ['bold', 'italic']],
                    ['para', ['ul', 'ol', 'paragraph']],
                    ['insert', ['table']]
                ],
                popover: {
                    air: [
                        ['style', ['bold', 'italic']],
                        ['para', ['ul', 'ol', 'paragraph']],
                        ['insert', ['table']]
                    ]
                }
            });
        });
    </script>
    <?php echo $__env->yieldPushContent('scripts'); ?>

</body>

</html>
<?php /**PATH /home/mant3325/public_html/dev.mantrasaktiautofilm.com/resources/views/layouts/admin.blade.php ENDPATH**/ ?>