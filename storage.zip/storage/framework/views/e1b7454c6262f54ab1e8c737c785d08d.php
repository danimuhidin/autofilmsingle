

<?php $__env->startSection('title', 'Mantra Sakti Autofilm - Spesialis Kaca Film Mobil & Gedung'); ?>
<?php $__env->startSection('page-title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>

    <section class="page-hero container-fluid" style="background-image: url(<?php echo e(asset('storage/' . $hero->image)); ?>);">
        <div class="hero-overlay"></div>
        <div class="hero-content">
            <h1 class="display-4 font-weight-bold"><?php echo e($hero->title); ?></h1>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="<?php echo e(URL::to('/')); ?>">Home</a></li>
                    <li class="breadcrumb-item active" aria-current="page">Kontak</li>
                </ol>
            </nav>
        </div>
    </section>

    <section class="contact-hq py-5">
        <div class="container">
            <h2 class="section-title">Hubungi Kantor Pusat</h2>
            <div class="row">
                <div class="col-md-7 mb-5 mb-md-0">
                    <h3 class="contact-subtitle">Kirim Pertanyaan Anda</h3>
                    <p class="text-secondary mb-4">Punya pertanyaan umum, kritik, saran, atau peluang bisnis? Silakan isi
                        formulir di bawah ini.</p>
                    <form action="#" method="POST">
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="formNama">Nama Lengkap</label>
                                <input type="text" class="form-control" id="formNama" placeholder="Nama Anda" required>
                            </div>
                            <div class="form-group col-md-6">
                                <label for="formEmail">Alamat Email</label>
                                <input type="email" class="form-control" id="formEmail" placeholder="email@anda.com"
                                    required>
                            </div>
                        </div>
                        <div class="form-row">
                            <div class="form-group col-md-6">
                                <label for="formTelepon">Nomor Telepon</label>
                                <input type="tel" class="form-control" id="formTelepon" placeholder="0812xxxxxx">
                            </div>
                            <div class="form-group col-md-6">
                                <label for="formSubjek">Subjek</label>
                                <input type="text" class="form-control" id="formSubjek" placeholder="Subjek Pesan"
                                    required>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="formPesan">Pesan Anda</label>
                            <textarea class="form-control" id="formPesan" rows="6" placeholder="Tuliskan pesan Anda di sini..." required></textarea>
                        </div>
                        <button type="submit" class="btn btn-merah">Kirim Pesan</button>
                    </form>
                </div>

                <div class="col-md-5">
                    <h3 class="contact-subtitle">Informasi Kantor Pusat</h3>
                    <ul class="contact-info-list">
                        <li>
                            <i class="fas fa-map-marker-alt"></i>
                            <span>
                                <strong>Alamat:</strong><br>
                                <?php echo e($bio->address); ?>

                            </span>
                        </li>
                        <li>
                            <i class="fas fa-phone"></i>
                            <span>
                                <strong>Telepon:</strong><br>
                                <?php echo e($bio->telp); ?>

                            </span>
                        </li>
                        <li>
                            <i class="fab fa-instagram"></i>
                            <span>
                                <strong>Instagram:</strong><br>
                                <?php echo e($bio->ig_name); ?>

                            </span>
                        </li>
                        <li>
                            <i class="fas fa-clock"></i>
                            <span>
                                <strong>Jam Operasional:</strong><br>
                                <?php echo e($bio->operation_time); ?>

                            </span>
                        </li>
                    </ul>

                    <div class="map-responsive mt-4">
                        <iframe src="<?php echo e($bio->link_maps_embed); ?>" width="600" height="450" style="border:0;"
                            allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="outlet-section py-5">
        <div class="container">
            <h2 class="section-title mb-2">Temukan Outlet Terdekat Kami</h2>
            <p class="text-center text-secondary col-md-12 mx-auto mb-5">
                Untuk pemasangan retail dan konsultasi langsung, silakan hubungi jaringan outlet resmi kami di bawah ini.
            </p>
            <div id="daftar-outlet">
                <div class="row">
                    <?php $__currentLoopData = $outlets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $outlet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-6 mb-4 h-100">
                            <div class="card outlet-card h-100">
                                <div class="card-body">
                                    <h5 class="card-title mb-2" style="color: var(--warna-kuning-aksen);">
                                        <b><?php echo e($outlet->name); ?></b>
                                    </h5>
                                    <p class="card-text text-white-50">
                                        <?php echo e($outlet->address); ?>

                                    </p>
                                    <p class="card-text text-white-50">
                                        <i class="fas fa-phone-alt"></i> <?php echo e($outlet->telp); ?>

                                    </p>
                                    <a target="_blank" href="<?php echo e($outlet->link1); ?>" class="btn btn-kuning btn-sm">
                                        Lihat Google Maps
                                    </a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
            <div class="text-center mt-4">
                <a href="<?php echo e(URL::to('/outlet')); ?>" class="btn btn-merah">Lihat
                    Semua Jaringan Outlet</a>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\Coding\portofolio\kacafilm\resources\views\contact.blade.php ENDPATH**/ ?>